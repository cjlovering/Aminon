#!/bin/bash

IP="$1"


wget asset.com --no-dns-cache

