#ip route del 10.4.6.128/25 via 10.4.6.1
ip route add 10.4.6.128/25 via 10.4.6.1
ip route
